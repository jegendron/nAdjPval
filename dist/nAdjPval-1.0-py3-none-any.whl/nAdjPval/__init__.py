# For function 1
from .main import nAdjPval

# For function 2
from .main import nAdjCalc